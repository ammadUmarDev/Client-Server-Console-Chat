package messages;

import Serialization.SerializedObject;

public class LoginRequest extends Message {

	/**
	 *
	 */
	private static final long serialVersionUID = -9221283922357697759L;
	String username;
	String password;

	LoginRequest() {
		msgType = "LoginRequest";
	}

	@Override
	public byte[] toBinary() {
		// int size=1000000;
		// byte[] array=new byte[size];
		return (new SerializedObject<LoginRequest>()).toByteStream(this);
	}

	@Override
	public LoginRequest fromBinary(byte[] array) {
		// TODO Auto-generated method stub
		return (new SerializedObject<LoginRequest>()).fromByteStream(array);
	}

	@Override
	public Object getField(String fieldName) {
		if (fieldName.equals("username"))
			return username;
		else if (fieldName.equals("password"))
			return password;
		return null;
	}

	@Override
	public void setField(String fieldName, Object fieldValue) {
		if (fieldName.equals("username"))
			username=(String)fieldValue;
		else if (fieldName.equals("password"))
			password=(String)fieldValue;
	}
}
