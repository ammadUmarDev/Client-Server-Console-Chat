package messages;

public class MessageContent {

}
